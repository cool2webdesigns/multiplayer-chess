# Real Chess Multiplayer

A browser-based multiplayer chess game using Python, FastAPI, WebSockets and python-chess.

## Features

- Two-player live multiplayer
- Automatic white/black assignment
- Room codes and shareable room URLs
- Legal move validation on the server
- Checkmate, stalemate, insufficient material, repetition and 50-move detection
- Chess clocks with increment support
- Move history
- Resignation
- Spectator mode
- Promotion
- Responsive mobile chessboard
- In-memory game storage

## Run on Windows/macOS/Linux

From the project directory:

```bash
cd server
python -m venv .venv
```

Activate it:

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install:

```bash
pip install -r requirements.txt
```

Start:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

Open:

http://localhost:8000

## Two devices on the same Wi-Fi

Find the computer's local IP address, for example `192.168.1.50`.

Start the server with:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

Then on both devices open:

```text
http://192.168.1.50:8000/?room=ABC123
```

Choose different player colours or leave it on Auto.

## Important

This first version stores games in memory. Restarting the server clears active games.

For a production version, add PostgreSQL/Redis, user accounts, matchmaking, ELO ratings, anti-cheat/rate limiting, persistent game records and HTTPS/WSS.
