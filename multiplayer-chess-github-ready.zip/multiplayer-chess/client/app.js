const $=id=>document.getElementById(id);
let ws=null, state=null, myRole=null, selected=null, pendingPromotion=null;
const pieceChars={
  wp:"♙",wn:"♘",wb:"♗",wr:"♖",wq:"♕",wk:"♔",
  bp:"♟",bn:"♞",bb:"♝",br:"♜",bq:"♛",bk:"♚"
};

function roomFromUrl(){
  const p=new URLSearchParams(location.search).get("room");
  return p || Math.random().toString(36).slice(2,8).toUpperCase();
}
$("room").value=roomFromUrl();

$("join").onclick=join;
$("newRoom").onclick=()=>{location.href=location.pathname+"?room="+Math.random().toString(36).slice(2,8).toUpperCase()};
$("resign").onclick=()=>{if(ws&&confirm("Resign this game?"))ws.send(JSON.stringify({action:"resign"}))};
$("reset").onclick=()=>{if(ws)ws.send(JSON.stringify({action:"new_game"}))};
$("copy").onclick=async()=>{await navigator.clipboard.writeText(location.href);$("message").textContent="Room link copied."};

function join(){
  const room=$("room").value.trim().toUpperCase();
  const name=$("name").value.trim()||"Player";
  if(!room)return;
  history.replaceState({}, "", "?room="+encodeURIComponent(room));
  $("lobby").hidden=true;$("game").hidden=false;$("roomLabel").textContent=room;
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}/ws/${encodeURIComponent(room)}`);
  ws.onopen=()=>ws.send(JSON.stringify({name,color:$("colour").value}));
  ws.onmessage=e=>{
    const msg=JSON.parse(e.data);
    if(msg.type==="role"){myRole=msg.role;$("role").textContent=myRole.toUpperCase();return}
    if(msg.type==="state"){state=msg;render()}
  };
  ws.onclose=()=>{$("message").textContent="Disconnected. Refresh to reconnect.";};
}

function parseFen(fen){
  const rows=fen.split(" ")[0].split("/");
  const pieces=[];
  for(const row of rows){
    const out=[];
    for(const c of row){
      if(/[1-8]/.test(c))for(let i=0;i<+c;i++)out.push(null);
      else out.push((c===c.toUpperCase()?"w":"b")+c.toLowerCase());
    }
    pieces.push(...out);
  }
  return pieces;
}
function squareName(i){return String.fromCharCode(97+i%8)+(8-Math.floor(i/8))}
function orientIndex(displayIndex){
  if(myRole==="black")return 63-displayIndex;
  return displayIndex;
}
function render(){
  $("whiteName").textContent=state.white;$("blackName").textContent=state.black;
  $("whiteStatus").textContent=state.white_connected?"Online": "Waiting";
  $("blackStatus").textContent=state.black_connected?"Online": "Waiting";
  $("whiteClock").textContent=formatClock(state.clocks.white);
  $("blackClock").textContent=formatClock(state.clocks.black);
  $("whitePlayer").style.outline=state.turn==="white"&&!state.game_over?"2px solid #d7a84b":"none";
  $("blackPlayer").style.outline=state.turn==="black"&&!state.game_over?"2px solid #d7a84b":"none";
  drawBoard();drawMoves();
  if(state.game_over)$("message").textContent=`${state.reason}: ${state.result}`;
  else if(myRole==="spectator")$("message").textContent="Spectating";
  else if(!state.white_connected||!state.black_connected)$("message").textContent="Waiting for both players…";
  else $("message").textContent=state.turn===myRole?"Your turn":"Opponent's turn";
}
function formatClock(s){
  s=Math.max(0,s);const m=Math.floor(s/60),sec=Math.floor(s%60);
  return `${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
}
function drawBoard(){
  const pieces=parseFen(state.fen);const board=$("board");board.innerHTML="";
  const legalFromSelected=state.legal_moves.filter(u=>u.slice(0,2)===selected);
  for(let d=0;d<64;d++){
    const i=orientIndex(d),sq=squareName(i),el=document.createElement("div");
    el.className="square "+(((Math.floor(i/8)+i%8)%2===0)?"light":"dark");
    if(selected===sq)el.classList.add("selected");
    if(legalFromSelected.some(u=>u.slice(2,4)===sq))el.classList.add("target");
    const pc=pieces[i];
    if(pc){const span=document.createElement("span");span.className="piece";span.textContent=pieceChars[pc];el.appendChild(span)}
    if(i%8===0){const c=document.createElement("span");c.className="coord";c.textContent=8-Math.floor(i/8);el.appendChild(c)}
    if(Math.floor(i/8)===7){const c=document.createElement("span");c.className="coord";c.style.left="auto";c.style.right="4px";c.style.top="auto";c.style.bottom="3px";c.textContent=String.fromCharCode(97+i%8);el.appendChild(c)}
    el.onclick=()=>clickSquare(sq);
    board.appendChild(el);
  }
}
function clickSquare(sq){
  if(!state||state.game_over||myRole!==state.turn)return;
  const piece=parseFen(state.fen)[squareToIndex(sq)];
  if(!selected){
    if(piece&&((myRole==="white"&&piece[0]==="w")||(myRole==="black"&&piece[0]==="b"))&&state.legal_moves.some(u=>u.slice(0,2)===sq))selected=sq;
    drawBoard();return;
  }
  const candidates=state.legal_moves.filter(u=>u.slice(0,2)===selected&&u.slice(2,4)===sq);
  if(candidates.length){
    const promo=candidates.find(u=>u.length===5);
    if(promo){pendingPromotion=candidates;showPromotion()}else sendMove(candidates[0]);
  }else if(piece&&piece[0]===(myRole==="white"?"w":"b"))selected=sq;
  else selected=null;
  drawBoard();
}
function squareToIndex(s){return (8-+s[1])*8+(s.charCodeAt(0)-97)}
function sendMove(uci){ws.send(JSON.stringify({action:"move",uci}));selected=null;pendingPromotion=null;$("promotion").hidden=true}
function showPromotion(){$("promotion").hidden=false}
document.querySelectorAll("[data-piece]").forEach(b=>b.onclick=()=>{const p=b.dataset.piece;const m=pendingPromotion.find(u=>u.endsWith(p));if(m)sendMove(m)});
function drawMoves(){
  const box=$("moves");box.innerHTML="";
  for(let i=0;i<state.history.length;i+=2){
    const row=document.createElement("div");row.className="moveRow";
    row.innerHTML=`<span>${i/2+1}.</span><span>${state.history[i]?.san||""}</span><span>${state.history[i+1]?.san||""}</span>`;
    box.appendChild(row);
  }
  box.scrollTop=box.scrollHeight;
}
setInterval(()=>{if(state&&!state.game_over){state.clocks[state.turn]=Math.max(0,state.clocks[state.turn]-.1);render()}},100);
