from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import chess
import chess.pgn
import io
import time
import uuid

app = FastAPI(title="Real Chess Multiplayer")

class Game:
    def __init__(self, game_id, initial_seconds=600, increment=0):
        self.id = game_id
        self.board = chess.Board()
        self.players = {}  # websocket -> color
        self.names = {"white": "White", "black": "Black"}
        self.spectators = set()
        self.initial_seconds = initial_seconds
        self.increment = increment
        self.clock = {"white": float(initial_seconds), "black": float(initial_seconds)}
        self.last_tick = time.monotonic()
        self.turn_started = self.last_tick
        self.game_over = False
        self.result = None
        self.reason = None
        self.history = []

    def color_name(self, color):
        return "white" if color == chess.WHITE else "black"

    def tick_clock(self):
        if self.game_over or self.board.turn not in (chess.WHITE, chess.BLACK):
            return
        now = time.monotonic()
        elapsed = now - self.turn_started
        side = self.color_name(self.board.turn)
        self.clock[side] = max(0, self.clock[side] - elapsed)
        self.turn_started = now
        if self.clock[side] <= 0:
            self.game_over = True
            self.result = "0-1" if side == "white" else "1-0"
            self.reason = "Time"

    def state(self):
        self.tick_clock()
        legal = []
        if not self.game_over:
            for m in self.board.legal_moves:
                legal.append(m.uci())
        return {
            "type": "state",
            "game_id": self.id,
            "fen": self.board.fen(),
            "turn": self.color_name(self.board.turn),
            "white": self.names["white"],
            "black": self.names["black"],
            "white_connected": any(c == "white" for c in self.players.values()),
            "black_connected": any(c == "black" for c in self.players.values()),
            "spectators": len(self.spectators),
            "clocks": {
                "white": round(self.clock["white"], 1),
                "black": round(self.clock["black"], 1)
            },
            "increment": self.increment,
            "history": self.history,
            "legal_moves": legal,
            "check": self.board.is_check(),
            "game_over": self.game_over,
            "result": self.result,
            "reason": self.reason
        }

games = {}

async def broadcast(game):
    message = game.state()
    dead = []
    for ws in list(game.players) + list(game.spectators):
        try:
            await ws.send_json(message)
        except Exception:
            dead.append(ws)
    for ws in dead:
        game.players.pop(ws, None)
        game.spectators.discard(ws)

@app.get("/")
async def root():
    return FileResponse("../client/index.html")

app.mount("/static", StaticFiles(directory="../client"), name="static")

@app.get("/health")
async def health():
    return {"ok": True, "games": len(games)}

@app.websocket("/ws/{game_id}")
async def websocket_endpoint(ws: WebSocket, game_id: str):
    await ws.accept()

    game = games.get(game_id)
    if not game:
        game = Game(game_id)
        games[game_id] = game

    role = None
    try:
        hello = await ws.receive_json()
        name = str(hello.get("name", "Player"))[:24] or "Player"
        requested = hello.get("color")

        occupied = set(game.players.values())
        if requested in ("white", "black") and requested not in occupied:
            role = requested
        elif "white" not in occupied:
            role = "white"
        elif "black" not in occupied:
            role = "black"
        else:
            game.spectators.add(ws)
            role = "spectator"

        if role in ("white", "black"):
            game.players[ws] = role
            game.names[role] = name
        await ws.send_json({"type": "role", "role": role, "game_id": game_id})
        await broadcast(game)

        while True:
            data = await ws.receive_json()
            action = data.get("action")

            if action == "move" and role in ("white", "black") and not game.game_over:
                if game.color_name(game.board.turn) != role:
                    continue

                uci = data.get("uci", "")
                try:
                    move = chess.Move.from_uci(uci)
                except ValueError:
                    continue

                if move not in game.board.legal_moves:
                    continue

                mover = game.color_name(game.board.turn)
                san = game.board.san(move)

                game.tick_clock()
                game.board.push(move)
                game.clock[mover] += game.increment
                game.turn_started = time.monotonic()

                game.history.append({
                    "ply": len(game.history) + 1,
                    "color": mover,
                    "san": san,
                    "uci": uci
                })

                if game.board.is_checkmate():
                    game.game_over = True
                    game.result = "1-0" if game.board.turn == chess.BLACK else "0-1"
                    game.reason = "Checkmate"
                elif game.board.is_stalemate():
                    game.game_over = True
                    game.result = "1/2-1/2"
                    game.reason = "Stalemate"
                elif game.board.is_insufficient_material():
                    game.game_over = True
                    game.result = "1/2-1/2"
                    game.reason = "Insufficient material"
                elif game.board.can_claim_threefold_repetition():
                    game.game_over = True
                    game.result = "1/2-1/2"
                    game.reason = "Threefold repetition"
                elif game.board.can_claim_fifty_moves():
                    game.game_over = True
                    game.result = "1/2-1/2"
                    game.reason = "50-move rule"

                await broadcast(game)

            elif action == "resign" and role in ("white", "black") and not game.game_over:
                game.game_over = True
                game.result = "0-1" if role == "white" else "1-0"
                game.reason = "Resignation"
                await broadcast(game)

            elif action == "new_game":
                if role in ("white", "black"):
                    game.board = chess.Board()
                    game.clock = {"white": float(game.initial_seconds), "black": float(game.initial_seconds)}
                    game.last_tick = time.monotonic()
                    game.turn_started = game.last_tick
                    game.history = []
                    game.game_over = False
                    game.result = None
                    game.reason = None
                    await broadcast(game)

    except WebSocketDisconnect:
        game.players.pop(ws, None)
        game.spectators.discard(ws)
        await broadcast(game)
    except Exception:
        game.players.pop(ws, None)
        game.spectators.discard(ws)
